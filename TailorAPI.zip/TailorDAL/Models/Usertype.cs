﻿using System;
using System.Collections.Generic;

namespace TailorDAL.Models
{
    public partial class Usertype
    {
        public int Usertypeid { get; set; }
        public string Usertype1 { get; set; }
        public bool? Isactive { get; set; }
    }
}
