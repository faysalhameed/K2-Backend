﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TailorBO.BOTailor
{
    public class TailorBOResponse
    {
        public int tailorid { get; set; }
        public string tailorcompanytitle { get; set; }
        public string tailorcompanyimage { get; set; }
        public string tailorrating { get; set; }
        public string tailorlatitude { get; set; }
        public string tailorlongitude { get; set; }
    }
}
